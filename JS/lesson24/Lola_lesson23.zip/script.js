let Age = 41;
let Year = 1981;
let MyName = 'Lola';

console.log(Age, Year, MyName);